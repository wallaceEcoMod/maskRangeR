2017 monthly NDVI images from: https://neo.sci.gsfc.nasa.gov/
https://neo.sci.gsfc.nasa.gov/view.php?datasetId=MOD_NDVI_M&year=2017


October 2017 Daily MODIS/Terra Surface Reflectance Daily L3 Global 0.05Deg CMG V006
https://search.earthdata.nasa.gov/data/configure?p=C193529901-LPDAAC_ECS&m=6.1875!-68.625!2!1!0!0%2C2&qt=2017-10-01T00%3A00%3A00.000Z%2C2017-10-31T23%3A59%3A59.000Z&q=MOD09CMG%20V006&sb=-101.8125%2C23.765625%2C-67.921875%2C46.96875&back=%2Fsearch%2Fgranules

