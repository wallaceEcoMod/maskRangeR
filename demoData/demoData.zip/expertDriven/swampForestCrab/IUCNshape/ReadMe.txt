The data you have downloaded falls under the Terms of Use of the IUCN Red List of Threatened Species. These terms can be checked on the www.iucnredlist.org website.

Please check the meta-data document attached for more information about the spatial data. This document is updated regularly, so always make sure to check on the www.iucnredlist.org website, under 'Resources / Resources and Publications -> Spatial Data download' for the latest version.

Point data, if available, is provided in CSV format.

For any questions, please contact the IUCN Red List Unit <redlistgis@iucn.org>
